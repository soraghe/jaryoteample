#include "MyServer.h"
#include <fcntl.h>
#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define PERMS 0644
#define MAX_BUF_SIZE 1024

void signalHandler(int signum);
void MakeInfo(char str[]);
void myError(const char *msg);
key_t mykey = 0;
int msqid = 0;
int main(int argc, char const* argv[]) {
    char *str, *spt;
	MsgCalc msgCalc;
	MsgRslt msgRslt;
	mykey = ftok("mymsgkey", 1); // �޼��� ť ����
	msqid = msgget(mykey, IPC_CREAT | 0600);
	signal(SIGINT, signalHandler);

	while (1) {
		puts("Wait ...");
        memset(&msgCalc, 0x00, sizeof(MsgCalc));
		msgrcv(msqid, &msgCalc, MSG_SIZE_CALC, MSG_TYPE_CALC, 0); // Ŭ���̾�Ʈ�� ���� ��ȣ ����
        
        
        // Ŭ���̾�Ʈ�� ���� ������ �ڷ���� ���������� DB�� �Է��� �ڷ������� ��ȯ 
	             printf("Receive: %s %s %d %d\n", msgCalc.calc.name, msgCalc.calc.id, msgCalc.calc.pwd,
                        msgCalc.calc.account);   
                 str = msgCalc.calc.name; 
                 spt=" ";
                 strcat(str, spt);
                 strcat(str, msgCalc.calc.id);
                 strcat(str, spt);
                 strcat(str, msgCalc.calc.pwd);
                 strcat(str, spt);
                 strcat(str, msgCalc.calc.account);
                 strcat(str,"\n");
                 MakeInfo(str);   // DB�� �Է�   
		         printf("Send: completed\n");
        
       
                memset(&msgRslt, 0x00, sizeof(MsgRslt));
                   msgRslt.mtype = MSG_TYPE_RSLT;
		msgRslt.rslt = "complete";
             
		msgsnd(msqid, &msgRslt, MSG_SIZE_RSLT, 0); // �ۿ��� �Ϸ��� �ÿ� Ŭ���̾�Ʈ�� ��ȣ ����
		fflush(stdout);
	}
	return 0;
}
void signalHandler(int signum) {
	if (signum == SIGINT) {
		msgctl(msqid, IPC_RMID, NULL);
		exit(0);
	}
}
void MakeInfo(char str[]) // DB ����
{
    int fd = 0;
    char * pathname = "./Data.txt";
    char * msg = str;
    ssize_t wsize = 0;

    fd = open(pathname, O_CREAT | O_APPEND | O_RDWR, PERMS );
                
    if (fd == -1){
        myError("open() error!");
    }

    wsize = write(fd, (char *)msg, strlen(msg));
    if (wsize == -1) {
            myError("write() error!");
    }

    close(fd);
}

void myError(const char *msg) { perror(msg); exit(-1); }


#ifndef __MYMSG_H__
#define __MYMSG_H__

#define MSG_TYPE_CALC 1
#define MSG_TYPE_RSLT 2

#define MSG_SIZE_CALC (sizeof(MsgCalc) - sizeof(long))
#define MSG_SIZE_RSLT (sizeof(MsgRslt) - sizeof(long))

struct __Calc {
    char name[50];
    char num[50];
};
typedef struct __Calc Calc;

struct __MsgCalc {
    long mtype;
    struct __Calc calc;
};

typedef struct __MsgCalc MsgCalc;

struct __MsgRslt {
    long mtype;
    char rslt[100];
};

typedef struct __MsgRslt MsgRslt;

#endif //!__MYMSG_H__
